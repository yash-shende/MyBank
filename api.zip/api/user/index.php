<?php
// required headers
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: GET,POST,PATCH,DELETE,PUT");
header("Access-Control-Max-Age: 3600");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

include("D:\\xampp\\htdocs\\mybank\\connection.php");

$reqMethod =  $_SERVER['REQUEST_METHOD'];

if($reqMethod=='GET'){
    echo "GET";
    doGet($conn);
    
}
else if($reqMethod=='PUT'){
    echo "PUT";
    doPut();
}
else if($reqMethod == 'POST'){
    doPost();
    echo "POST";
}
else if($reqMethod == 'DELETE'){
    echo "DELETE";
    doDelete($conn);
}
else{
    http_response_code(405);
}



function doGet($conn){
    
    $Received_id = isset($_GET['id']) ? $_GET['id'] :null;
    if($Received_id==null){
        readAllUser($conn);
    }
    else{
        readUser($Received_id,$conn);
    }
    
}

function doPost(){
    
}

function doPut(){
    echo "inside Put";
}

function doDelete($conn){
    $Received_id = isset($_GET['id']) ? $_GET['id'] :null;
    if($Received_id==null){
        echo json_encode(array("Message "=>"No id Provided"));
    }
    else{
        delUser($Received_id,$conn);
    }
}


//GET functions for Read operations 
function readAllUser($conn){
    $query = "select * from dtbase ";
    $result = mysqli_query($conn,$query) or die("query failed");

    if(mysqli_num_rows($result)>0){

        while($row = mysqli_fetch_assoc($result)){
            echo json_encode($row);
        }

    }
}

function readUser($id,$conn){
    $query = "select * from dtbase where id=".$id;
    $result = mysqli_query($conn,$query) or die("query failed");

    if(mysqli_num_rows($result)>0){

        while($row = mysqli_fetch_assoc($result)){
            echo json_encode($row);
        }

    }
    else{
        http_response_code(400);
        echo json_encode(array("message"=>"Invalid Id"));
    }
}
//GET methods over ! ---------------------------------------------


function delUser($id,$conn){
        
    $query = "select * from dtbase where id=".$id;
    $result = mysqli_query($conn,$query) or die("query failed");

    if(mysqli_num_rows($result)>0){

        while($row = mysqli_fetch_assoc($result)){
            echo "id PResnt";
        }

    }
    else{
        echo "NO prest";
    }
    
}

?>